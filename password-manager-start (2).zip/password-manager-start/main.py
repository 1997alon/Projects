from tkinter import *
from tkinter import messagebox
import pyperclip
import json
# Constants
CANVAS_WIDTH = 200
CANVAS_HEIGHT = 200
LIGHT_YELLOW = "#E4E4D0"
LIGHT_GRAY = "#E3E1D9"
LIGHT_BLUE = "#40A2D8"
global name
name = None
# ---------------------------- Who Are You ------------------------------- #
def enter(name_entry):
    global name
    name = name_entry.get()

def who_are_you():
    window = Tk()
    window.title("Hello")
    window.minsize(width=400, height=400)
    window.config(padx=50, pady=50, bg=LIGHT_BLUE)

    canvas = Canvas(width=250, height=250, highlightthickness=0)
    hello = PhotoImage(file="hello.png")
    canvas.create_image(120, 120, image=hello)
    canvas.grid(column=1, row=0)
    
    name_label = Label(text="What's your name?:", font=("Arial", 10), bg=LIGHT_BLUE)
    name_label.grid(column=0, row=2, sticky="s")
    
    name_entry = Entry(width=41, bg="white")
    name_entry.grid(column=1, row=2, sticky="w")
    
    def on_enter():
        enter(name_entry)
        window.destroy()  # Close the window after retrieving the name
    
    name_button = Button(text='Enter', font=("Arial", 10), bg=LIGHT_GRAY, command=on_enter)
    name_button.grid(column=2, row=2, sticky="s")

    window.mainloop()
# ---------------------------- PASSWORD GENERATOR ------------------------------- #
def generate_password():
    password_entry.delete(0, END)
    import random
    letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    symbols = ['!', '#', '$', '%', '&', '(', ')', '*', '+']

    password_letters = [random.choice(letters) for _ in range(random.randint(8, 10))]
    password_symbols = [random.choice(symbols) for _ in range(random.randint(1, 2))]
    password_numbers = [random.choice(numbers) for _ in range(random.randint(2, 4))]
    password_list = password_letters + password_numbers + password_symbols
    
    random.shuffle(password_list)
    password = "".join(password_list)
    password_entry.insert(0, (password))
    pyperclip.copy(password)
    
# ---------------------------- SAVE PASSWORD ------------------------------- #
def delete():
    website_entry.delete(0, END)
    password_entry.delete(0, END)
    
def save():
    global name
    website = website_entry.get()
    email = email_username_entry.get()
    password = password_entry.get()
    new_data = {website:{
        "email" : email,
        "password" : password
    }}
    if password == "" or website == ""  or email == "":
        messagebox.showinfo("Oops", "Please dont leave any fields empty!")
    else: 
        try:                      
            with open(f"saving_{name}.json", "r") as file:
                data = json.load(file)
                data.update(new_data)
        except:
            with open(f"saving_{name}.json", "w") as file:
                json.dump(new_data, file, indent=4) 
        else:               
            with open(f"saving_{name}.json", "w") as file:    
                json.dump(data, file, indent=4)
    delete()     
    
def search():
    global name
    website = website_entry.get()
    try:
        with open(f"saving_{name}.json", "r") as file:
            json_data = json.load(file)
    except:
        messagebox.showwarning("Oops", "There is no data")
    else:
        if website in json_data:
            email = json_data[website]["email"]
            password = json_data[website]["password"]
            messagebox.showinfo("Found", f"Website: {website}\nEmail: {email}\nPassword: {password}")
        else:
            messagebox.showinfo("Not Found", f"Website '{website}' not found in the data")
            
                            
# ---------------------------- UI SETUP ------------------------------- #
who_are_you()
print(name)
if not name:
   exit()
name = name.title()   
 
window = Tk()
window.title(f"Password Manager for {name}")
window.minsize(width=210, height=210)
window.config(padx=50, pady=50, bg = LIGHT_YELLOW)


canvas = Canvas(width=CANVAS_WIDTH, height=CANVAS_HEIGHT, highlightthickness=0)
lock = PhotoImage(file="logo.png")
canvas.create_image(CANVAS_WIDTH // 2, CANVAS_HEIGHT // 2, image=lock)
canvas.create_rectangle(2, 2, CANVAS_WIDTH - 2, CANVAS_HEIGHT - 2, outline="black", width=3)
canvas.grid(column=1, row=0)

website_label = Label(text ='Website:', font = ("Ariel", 10), bg = LIGHT_YELLOW)
website_label.grid(column=0, row=1, sticky="s")

website_entry = Entry(width=34, bg="white")
website_entry.grid(column=1, row=1, sticky="w")
website_entry.focus()

email_username_label = Label(text ='Email/Username:', font = ("Ariel", 10), bg = LIGHT_YELLOW)
email_username_label.grid(column=0, row=2)

email_username_entry = Entry(width=52, bg="white")
email_username_entry.grid(column=1, row=2, sticky="w", columnspan=2)
email_username_entry.insert(0, "bardinalon@gmail.com")


password_label = Label(text ='Password:', font = ("Ariel", 10), bg = LIGHT_YELLOW)
password_label.grid(column=0, row=3)

password_entry = Entry(width=34, bg="white")
password_entry.grid(column=1, row=3, sticky="w")


generate_password_button = Button(text="Generate Password", width=14, padx=0, pady=0, bg=LIGHT_GRAY, command=generate_password)
generate_password_button.grid(column=2, row=3, sticky="w")

add_button = Button(text="Add", width=44, padx=0, pady=0, bg=LIGHT_GRAY, command=save)
add_button.grid(column=1, row=4, sticky="w", columnspan=2)

search_button = Button(text="Search", width=14, padx=0, pady=0, bg=LIGHT_GRAY, command=search)
search_button.grid(column=2, row=1, sticky="w")

window.mainloop()